.. include:: ../README.md
   :parser: myst_parser.sphinx_

*****************
Table of Contents
*****************

.. include:: toc.rst

