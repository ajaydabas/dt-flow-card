##############
Reporting Bugs
##############

This section guides you through submitting a bug report for the DT Power Flow Card.
Following these guidelines helps maintainers and the community understand your report,
reproduce the behaviour, and find related reports.

Before creating bug reports, please check the below information as you might find out
that you don't need to create one. When you are creating a bug report,
please include as many details as possible, the information it asks for helps
us resolve issues faster.

.. note::

   If you find a **Closed** issue that seems like it is the same thing that you're
   experiencing, open a new issue and include a link to the original issue in the
   body of your new one.


******************************
Before Submitting A Bug Report
******************************

* **Perform a** `cursory search <https://github.com/slipx06/dt-power-flow-card/issues?q=is%3Aissue>`_
  to see if the problem has already been reported. If it has **and the issue is still open**, add a comment to
  the existing issue instead of opening a new one.

*****************************
How do i submit a bug report?
*****************************

Bugs are tracked as `GitHub issues <https://guides.github.com/features/issues/>`_.
After you've determined this is not a configuration issue, create an issue on github
and provide the following information by filling in `the template <https://github.com/slipx06/dt-power-flow-card/issues/new?assignees=&labels=type%2Fbug&projects=&template=bug_report.yml>`_.

Explain the problem and include additional details to help maintainers reproduce the problem:

- **Use a clear and descriptive title** for the issue to identify the problem.
- **Describe the exact steps which reproduce the problem** in as many details as possible. For example, start by explaining how you installed the plugin. When listing steps, **don't just say what you did, but explain how you did it**. For example, did you use the Lovelace Editor or do the change in YAML directly.
- **Provide specific examples to demonstrate the steps**. Include screenshots, or copy/pasteable configuration snippets, which you use in those examples. If you're providing snippets in the issue, use `Markdown code blocks <https://help.github.com/articles/markdown-basics/#multiple-lines>`_.
- **Describe the behaviour you observed after following the steps** and point out what exactly is the problem with that behaviour.
- **Explain which behaviour you expected to see instead and why.**
- **Include screenshots and animated GIFs** which show you following the described steps and clearly demonstrate the problem.
- **If Chrome's developer tools pane is showing errors**, include these in your report
- **If the problem wasn't triggered by a specific action**, describe what you were doing before the problem happened and share more information using the guidelines below.

Provide more context by answering these questions:

- **Did the problem start happening recently** (e.g. after updating to a new version of HA / DT Power Flow Card) or was this always a problem?
- If the problem started happening recently, **can you reproduce the problem in an older version of the card?** What's the most recent version in which the problem doesn't happen? You can install older versions of Atomic Calendar Revive via HACS or from the releases page on github
- **Can you reliably reproduce the issue?** If not, provide details about how often the problem happens and under which conditions it normally happens.
