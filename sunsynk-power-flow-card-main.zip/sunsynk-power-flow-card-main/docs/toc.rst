.. toctree::
   :caption: Configuration
   :titlesonly:

   configuration

.. toctree::
   :caption: Examples
   :titlesonly:

   examples/dt
   examples/foxess
   examples/goodwe
   examples/huawei
   examples/lux
   examples/powmr
   examples/solax
   examples/solis
   examples/victron

.. toctree::
   :caption: Contribute
   :titlesonly:

   contribute/bugs
   contribute/devcontainer
   contribute/devcycle
   contribute/docs
